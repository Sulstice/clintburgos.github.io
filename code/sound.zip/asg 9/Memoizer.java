import java.util.HashMap;

public class Memoizer
{
  public HashMap map = new HashMap();
  public Functor func = null;
  
  public Memoizer(Functor f) {
    func = f;
  }
  
  public Object call(Object x) {
    if(map.containsKey(x))
      return map.get(x);
    Object value = func.fn(x);
    map.put(x, value);
    return value;
  }
}
    